Launch Menu Version 1.2 19/03/2019

GENERAL USAGE NOTES
--------------------

- Launch Menu does not support Windows older than Vista.


Add/Edit/Remove Categories on Launch Menu
------------------------------------------
To Add/Edit/Remove Categories on Launch Menu, you need to run Launch Manager.

To Add Category, Click on 'Category' under 'SETTING', Type in Name, Index, Select Type, Icon and Check Display Icon.
Name - Name of the Category.
Index - Index of the Category, Must be unique number, Launch Menu use this number to sort it.
Type - Select from Game, Application, Movie and Separator. Note: Separator doesn't allow to add Items and Icon.
Icon - Icon of the Category.
Display Icon - If this option is checked, Icon will display on Launch Menu.
Click 'Add' button to add the category, then finally click 'Save' button to save the Categories.

To Edit Category, double click or right click and select 'Edit' on any of the existing Category. After edit click 'Edit' button to edit the category, then finally click 'Save' button to save the Categories.

To Remove Category, right click and select 'Delete' on any of the existing Category. Click 'Save' button to save the Categories.


Add/Edit/Remove Games on Launch Menu
-------------------------------------
To Add/Edit/Remove Games on Launch Menu, you need to run Launch Manager.

To Add Game, Click on the 'Game' under 'TYPE'. Select a Category and Type in Name, Path, Start In, Website, Description, Gerne, Publisher, Developer, Select Rating and Choose a Cover Art.
Name - Name of the Game.
Path - Path of the Game.
Start In - Directory of the Game. Note: Shortcut files (.lnk) or URL files/Steam Games Shortcut files/Discord Games Shortcut files (.url) don't need to enter this.
Website - Website of the Game. Leave blank to automatic generate.
Description - Description of the Game.
Gerne - Gerne of the Game. Can Add/Edit/Remove on 'Game' under 'SETTING'.
Rating - ESRB/PEGI Rating of the Game.
Publisher - Game Publisher. Can Add/Edit/Remove on 'Game' under 'SETTING'.
Developer - Game Developer. Can Add/Edit/Remove on 'Game' under 'SETTING'.
Cover Art - The Image/Icon of the Game.
Click 'Add' button to add the game, then finally click 'Save' button to save the Games.

To Edit Game, double click or right click and select 'Edit' on any of the existing Game. After edit click 'Edit' button to edit the game, then finally click 'Save' button to save the Games.

To Remove Game, right click and select 'Delete' on any of the existing Game. Click 'Save' button to save the Games.


Add/Edit/Remove Applications on Launch Menu
--------------------------------------------
To Add/Edit/Remove Applications on Launch Menu, you need to run Launch Manager.

To Add Application, Click on the 'Application' under 'TYPE'. Select a Category and Type in Name, Path, Start In, Website, Description, Type, Developer, and Choose an Icon.
Name - Name of the Application.
Path - Path of the Application.
Start In - Directory of the Application. Note: Shortcut files (.lnk) or URL files/Steam Applications Shortcut files/Discord Applications Shortcut files (.url) don't need to enter this.
Website - Website of the Application. Leave blank to automatic generate.
Description - Description of the Application.
Type - Type of the Application. Can Add/Edit/Remove on 'Application' under 'SETTING'.
Developer - Application Developer. Can Add/Edit/Remove on 'Application' under 'SETTING'.
Icon - Icon of the Application.
Click 'Add' button to add the Application, then finally click 'Save' button to save the Applications.

To Edit Application, double click or right click and select 'Edit' on any of the existing Application. After edit click 'Edit' button to edit the Application, then finally click 'Save' button to save the Applications.

To Remove Application, right click and select 'Delete' on any of the existing Application. Click 'Save' button to save the Applications.


Add/Edit/Remove Movies on Launch Menu
--------------------------------------
To Add/Edit/Remove Movies on Launch Menu, you need to run Launch Manager.

To Add Movie, Click on the 'Movie' under 'TYPE'. Select a Category and Type in Name, Path, Website, Description, Starring, Gerne, Director, Production Company, Distributor Company and Choose a Poster.
Name - Name of the Movie.
Path - Path of the Movie.
Website - Website of the Movie. Leave blank to automatic generate.
Description - Description of the Movie.
Starring - Actors of the Movie, and add up to 3 actors. Can Add/Edit/Remove on 'Movie' under 'SETTING'.
Gerne - Gerne of the Movie. Can Add/Edit/Remove on 'Movie' under 'SETTING'.
Director - Movie Director.
Production - Production Company. Can Add/Edit/Remove on 'Movie' under 'SETTING'.
Distributor - Movie Distributor. Can Add/Edit/Remove on 'Movie' under 'SETTING'.
Poster - The Poster of the Movie.
Click 'Add' button to add the Movie, then finally click 'Save' button to save the Movies.

To Edit Movie, double click or right click and select 'Edit' on any of the existing Movie. After edit click 'Edit' button to edit the Movie, then finally click 'Save' button to save the Movies.

To Remove Movie, right click and select 'Delete' on any of the existing Movie. Click 'Save' button to save the Movies.


Edit Settings
--------------
Click on 'General' under 'SETTING' and you are able to Edit the Settings.


Change the News Feeds on Activity Tab
--------------------------------------
Run Launch Manager, Click on 'General' under 'SETTING', Select the Options from Activity Feeds or you can use your own feeds by select 'Custom', Enter the RSS 'Feeds URL' and 'Media Node' then click 'Save' button.
Feeds URL - RSS feeds of the website.
Media Node - The Image of the feed, example: <media:content url="https://example.com/image/media.png" type="image/png" width="480" height="270"/> the Media Node will be 'media:content/@url'


Add/Remove Quick Launcher Applications
---------------------------------------
Run Launch Manager, Click on 'General' under 'SETTING', Check or Un-check the options on 'Quick Launcher', click 'Save' button.


Changelog
----------
v1.2.319.1
- Fixed Launch Menu loading forever after the last update.

v1.2.318.0
- Fixed error while editing Category.
- Fixed "out of memory" error.
- Fixed launcher not staying on top.
- Added multiselect for copy and delete.
- Added a small console logo on top right for non-pc games.
- Added title name on menu.

v1.1.316.0
- Fixed error while activating trial without administrator rights.
- Fixed error while extracting from auto update.
- Added command-line support for both games and applications.
- Added a few emulator support:
  * ePSXe - PlayStation 1 emulator
  * PCSX2 - PlayStation 2 emulator
  * RPCS3 - PlayStation 3 emulator
  * PPSSPP - PlayStation Portable emulator
  * Xenia - Xbox 360 emulator
  * Cemu - Wii U emulator
  * TeknoParrot - PC-based Arcade Games emulator
  * Demul - Dreamcast, Naomi, Atomiswave, Hikaru other SuperH or PowerVR 2-based systems emulator


To Order the Program can be reached at:
----------------------------------------
Phone: +6012-9036-980
Website: www.zettabytetek.com
E-mail: qiangqiang101@hotmail.com


Copyright (c) 2014 - 2019 Zettabyte Technology. All rights reserved.